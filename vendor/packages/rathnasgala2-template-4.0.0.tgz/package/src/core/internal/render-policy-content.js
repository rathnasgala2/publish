/**
 * The single source of truth for `contracts/render-policy.jcs`'s content:
 * the markdown, sanitizer, highlighter and per-artifact CSP baseline, and
 * the `renderPolicyIdentity` derived from them.
 *
 * `scripts/generate-contracts.mjs` emits this exact document as compact JCS
 * to `contracts/render-policy.jcs`; `src/core/internal/content-security.js`
 * consumes the same constants to build the actual markdown-it, sanitize-html
 * and highlighter configuration this renderer runs, and to compute the
 * `renderPolicyIdentity` every `renderableBody.renderPolicy` in a
 * `build-input:2.0.0` instance must byte-equal. Keeping both in one module
 * makes drift between "the policy we publish" and "the policy we enforce"
 * structurally impossible.
 */

/** @type {string} */
export const RENDER_POLICY_NAME = 'gala-render-policy';

/**
 * Byte-equal to the template lock's `contractVersion`, which every
 * `build-input:2.0.0` fixture in this repository carries as the literal
 * string `"2.0.0"` (matches `manifest.js`'s `buildInputContractVersion`).
 *
 * @type {string}
 */
export const RENDER_POLICY_VERSION = '2.0.0';

/** @type {string} */
export const MARKDOWN_IT_PACKAGE = 'markdown-it';
/** @type {string} */
export const MARKDOWN_IT_VERSION = '14.3.1';

/**
 * The exact markdown-it construction options this renderer requires.
 *
 * @type {{html: false, linkify: false, typographer: false}}
 */
export const MARKDOWN_IT_OPTIONS = Object.freeze({
  html: false,
  linkify: false,
  typographer: false,
});

/** @type {string} */
export const SANITIZER_PACKAGE = 'sanitize-html';
/** @type {string} */
export const SANITIZER_VERSION = '2.17.7';

/**
 * URL schemes admitted for `a[href]`. Same-document fragments and
 * repository-relative paths carry no scheme and are handled separately.
 *
 * @type {readonly string[]}
 */
export const ALLOWED_URL_SCHEMES = Object.freeze(['https', 'http', 'mailto']);

/**
 * The closed allowlist of tags this renderer ever emits from author
 * markdown: semantic text and content tags only.
 * No form, frame, SVG, MathML, script, style, object or template element is
 * ever admitted.
 *
 * @type {readonly string[]}
 */
export const ALLOWED_TAGS = Object.freeze([
  'p',
  'br',
  'hr',
  'h1',
  'h2',
  'h3',
  'h4',
  'h5',
  'h6',
  'ul',
  'ol',
  'li',
  'blockquote',
  'pre',
  'code',
  'strong',
  'em',
  'b',
  'i',
  'u',
  's',
  'del',
  'ins',
  'sub',
  'sup',
  'mark',
  'small',
  'wbr',
  'a',
  'img',
  'table',
  'thead',
  'tbody',
  'tr',
  'th',
  'td',
  'dl',
  'dt',
  'dd',
  'figure',
  'figcaption',
  'span',
]);

/**
 * The closed per-tag attribute allowlist. `id` is admitted only on headings
 * (this renderer's own generated heading IDs); `style`, every `on*` handler,
 * `srcdoc` and every other undeclared attribute is always stripped.
 *
 * @type {Readonly<Record<string, readonly string[]>>}
 */
export const ALLOWED_ATTRIBUTES_BY_TAG = Object.freeze({
  h1: Object.freeze(['id']),
  h2: Object.freeze(['id']),
  h3: Object.freeze(['id']),
  h4: Object.freeze(['id']),
  h5: Object.freeze(['id']),
  h6: Object.freeze(['id']),
  a: Object.freeze(['href', 'rel']),
  img: Object.freeze(['src', 'alt']),
  ol: Object.freeze(['start']),
  pre: Object.freeze(['class']),
  code: Object.freeze(['class']),
  span: Object.freeze(['class']),
});

/** @type {string} */
export const HIGHLIGHTER_PACKAGE = '@11ty/eleventy-plugin-syntaxhighlight';
/** @type {string} */
export const HIGHLIGHTER_VERSION = '5.0.2';

/**
 * The closed grammar-name catalog the owned highlighter accepts. A fence
 * language outside this list always falls back to escaped, unhighlighted
 * code.
 *
 * @type {readonly string[]}
 */
export const HIGHLIGHT_GRAMMARS = Object.freeze(
  [
    'bash',
    'css',
    'diff',
    'java',
    'javascript',
    'json',
    'jsx',
    'markdown',
    'markup',
    'python',
    'sql',
    'tsx',
    'typescript',
    'yaml',
  ].sort(),
);

/**
 * The closed `span.class` token-class catalog admitted on highlighted code,
 * grounded in the actual Prism.js token classes {@link HIGHLIGHT_GRAMMARS}
 * can produce (Prism's documented generic token set plus this
 * repository's own empirical sample across every admitted grammar). `token`
 * itself is always the base class; every other admitted value is a
 * secondary token-class: `span` elements carry `token` plus admitted
 * token-class values.
 *
 * @type {readonly string[]}
 */
export const ADMITTED_TOKEN_CLASSES = Object.freeze(
  [
    'token',
    'atrule',
    'attr-equals',
    'attr-name',
    'attr-value',
    'bold',
    'boolean',
    'builtin',
    'cdata',
    'char',
    'class-name',
    'comment',
    'constant',
    'content',
    'coord',
    'deleted',
    'deleted-sign',
    'doctype',
    'entity',
    'for-or-select',
    'function',
    'function-variable',
    'important',
    'inserted',
    'inserted-sign',
    'interpolation',
    'interpolation-punctuation',
    'italic',
    'key',
    'keyword',
    'namespace',
    'null',
    'number',
    'operator',
    'prefix',
    'prolog',
    'property',
    'punctuation',
    'regex',
    'rule',
    'selector',
    'shebang',
    'string',
    'symbol',
    'tag',
    'template-punctuation',
    'template-string',
    'title',
    'url',
    'variable',
  ].sort(),
);

/**
 * The closed `pre.class`/`code.class` catalog for highlighted fences: one
 * `language-<grammar>` value per {@link HIGHLIGHT_GRAMMARS} entry. An
 * unknown fence language's own `language-<arbitrary>` class (emitted by
 * markdown-it's own escaped fallback renderer) is not in this list and is
 * stripped by the sanitizer, matching the "escaped fallback" contract.
 *
 * @type {readonly string[]}
 */
export const ADMITTED_LANGUAGE_CLASSES = Object.freeze(
  HIGHLIGHT_GRAMMARS.map((grammar) => `language-${grammar}`),
);

/**
 * The production Galascribe API origin. The blog CSP always allows it in
 * `connect-src` (reader interactions design D8), interactions on or off.
 *
 * @type {string}
 */
export const PRODUCTION_API_ORIGIN = 'https://api.galascribe.com';

/**
 * The CSP specification explicitly ignores `frame-ancestors`
 * (and `report-uri`/`sandbox`, neither used here) when a policy is
 * delivered via `<meta http-equiv>` — browsers drop the directive and log a
 * console warning on every page load. `frame-ancestors` is therefore
 * split out as the one header-only directive: clickjacking protection for a
 * published artifact is a hosting-layer obligation (a response header, most
 * commonly `Content-Security-Policy` or `X-Frame-Options`), recorded here so
 * every consuming adapter/deployment knows to add it, rather than a directive
 * that silently does nothing inside the `<meta>` tag every page already
 * carries.
 *
 * @type {readonly string[]}
 */
export const CSP_HEADER_ONLY_DIRECTIVES = Object.freeze([
  "frame-ancestors 'none'",
]);

/**
 * The exact per-artifact CSP baseline actually deliverable inside a
 * `<meta http-equiv="Content-Security-Policy">` tag: {@link CSP_HEADER_ONLY_DIRECTIVES}
 * is excluded. Directive order is byte-exact, minus
 * the excluded directive; every directive's value list is already sorted
 * bytewise and duplicate-free. `connect-src` always admits the production
 * Galascribe API origin (reader interactions, whether or not the module is
 * on), so this string is byte-identical on every route of every production
 * build. Only the local stack's differing interactions `apiOrigin` is
 * appended per build ({@link contentSecurityPolicyMeta}).
 *
 * @type {string}
 */
export const CONTENT_SECURITY_POLICY_META_BASELINE =
  "default-src 'none'; base-uri 'none'; object-src 'none'; " +
  "form-action 'none'; script-src 'self'; " +
  "style-src 'self'; img-src 'self'; font-src 'self'; " +
  `connect-src 'self' ${PRODUCTION_API_ORIGIN}; ` +
  "media-src 'self'; manifest-src 'self'; worker-src 'none'";

/**
 * The complete CSP baseline this renderer originally specified as one
 * string — the meta-safe directives plus the header-only directive, in
 * this fixed byte-exact order — kept only as the render-policy identity's own
 * digest input (`renderPolicyDocument`'s `contentSecurityPolicy` field): a
 * hosting adapter that delivers this policy as a response header, rather
 * than a `<meta>` tag, may deliver this complete string unmodified.
 *
 * @type {string}
 */
export const CONTENT_SECURITY_POLICY_COMPLETE =
  "default-src 'none'; base-uri 'none'; object-src 'none'; " +
  "frame-ancestors 'none'; form-action 'none'; script-src 'self'; " +
  "style-src 'self'; img-src 'self'; font-src 'self'; " +
  `connect-src 'self' ${PRODUCTION_API_ORIGIN}; ` +
  "media-src 'self'; manifest-src 'self'; worker-src 'none'";

/**
 * The meta-safe CSP for one build. Identical to
 * {@link CONTENT_SECURITY_POLICY_META_BASELINE} unless the interactions
 * module names a different API origin (local stack only), in which case that
 * origin is added to `connect-src`, sorted bytewise with the other sources
 * and de-duplicated.
 *
 * @param {string | undefined} [apiOrigin] the interactions module's
 *   `apiOrigin`, when the module is on
 * @returns {string} the CSP directive string for the `<meta>` tag
 */
export function contentSecurityPolicyMeta(apiOrigin) {
  if (apiOrigin === undefined || apiOrigin === PRODUCTION_API_ORIGIN) {
    return CONTENT_SECURITY_POLICY_META_BASELINE;
  }
  const sources = [...new Set(["'self'", PRODUCTION_API_ORIGIN, apiOrigin])];
  sources.sort((a, b) => (a < b ? -1 : a > b ? 1 : 0));
  return CONTENT_SECURITY_POLICY_META_BASELINE.replace(
    `connect-src 'self' ${PRODUCTION_API_ORIGIN};`,
    `connect-src ${sources.join(' ')};`,
  );
}

/**
 * Build the exact plain-object document `contracts/render-policy.jcs`
 * publishes: `name`, `version` byte-equal to the template lock's
 * `contractVersion`, a closed sanitizer/parser catalog, and no self-digest.
 *
 * @returns {Record<string, unknown>} the render-policy document
 */
export function renderPolicyDocument() {
  return {
    name: RENDER_POLICY_NAME,
    version: RENDER_POLICY_VERSION,
    contentSecurityPolicy: CONTENT_SECURITY_POLICY_COMPLETE,
    contentSecurityPolicyMeta: CONTENT_SECURITY_POLICY_META_BASELINE,
    contentSecurityPolicyHeaderOnlyDirectives: [...CSP_HEADER_ONLY_DIRECTIVES],
    markdownIt: {
      package: MARKDOWN_IT_PACKAGE,
      version: MARKDOWN_IT_VERSION,
      options: { ...MARKDOWN_IT_OPTIONS },
    },
    sanitizer: {
      package: SANITIZER_PACKAGE,
      version: SANITIZER_VERSION,
      allowedTags: [...ALLOWED_TAGS],
      allowedAttributes: Object.fromEntries(
        Object.entries(ALLOWED_ATTRIBUTES_BY_TAG).map(([tag, attrs]) => [
          tag,
          [...attrs],
        ]),
      ),
      allowedUrlSchemes: [...ALLOWED_URL_SCHEMES],
    },
    highlighter: {
      package: HIGHLIGHTER_PACKAGE,
      version: HIGHLIGHTER_VERSION,
      grammars: [...HIGHLIGHT_GRAMMARS],
      tokenClasses: [...ADMITTED_TOKEN_CLASSES],
    },
  };
}
